package week03;

import java.util.Scanner;

public class StringReverser {

	public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String sentence = scanner.nextLine();

        // Split the input sentence into words
        String[] words = sentence.split(" ");
        // StringBuilder to store the reversed sentence
        StringBuilder reversedSentence = new StringBuilder();

        // Iterate over each word in the input sentence
        for (String word : words) {
            // StringBuilder to store the reversed word
            StringBuilder reversedWord = new StringBuilder();
            // Iterate over the characters of the word in reverse order
            for (int i = word.length() - 1; i >= 0; i--) {
                // Append each character to the reversedWord StringBuilder
                reversedWord.append(word.charAt(i));
            }
            // Append the reversed word followed by a space to the reversedSentence StringBuilder
            reversedSentence.append(reversedWord).append(" ");
        }

       
        System.out.println("Reversed sentence:");
        System.out.println(reversedSentence.toString().trim());

        scanner.close();

	}

}
