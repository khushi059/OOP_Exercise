package week03;

public class PunctuationCounter {

	public static void main(String[] args) {
		
		String text = "Mary had a little lamb, her fleece was as white as snow, and everywhere Mary went, the lamb was sure to go. -that was a nice poem- the end. ";
        int totalPunctuationMarks = 0;

        // Create a character array to store all considered punctuation marks
        char[] punctuations = {'!', ',', '.', '?', '-', '"'};

        // Create a hash table to store the count of each punctuation mark
        int[] punctuationCounts = new int[punctuations.length];

        for (char ch : text.toCharArray()) {
            for (int i = 0; i < punctuations.length; i++) {
                if (ch == punctuations[i]) {
                    punctuationCounts[i]++;
                    totalPunctuationMarks++;
                    break;
                }
            }
        }

        // Print the table header
        System.out.println("Punctuation Mark    Count");
        System.out.println("-----------------  -------");

        // Print the count of each punctuation mark
        for (int i = 0; i < punctuations.length; i++) {
            System.out.println("      " + punctuations[i] + "               " + punctuationCounts[i]);
        }

        System.out.println("-------------------------");
        System.out.println("Total Punctuation Marks: " + totalPunctuationMarks);

	}

}
