package hospital;

//Doctor class
class Doctor extends Employee {
 private String specialty;

 public Doctor(int empNumber, String specialty) {
     super(empNumber);
     this.specialty = specialty;
 }

 public void treatPatient() {
     System.out.println("Doctor Emp#" + getEmpNumber() + " specializes in " + specialty);
 }
}
