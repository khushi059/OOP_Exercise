package hospital;

//Cleaner class
class Cleaner extends Employee {
 public Cleaner(int empNumber) {
     super(empNumber);
 }

 public void clean() {
     System.out.println("Cleaner Emp#" + getEmpNumber() + " is sweeping");
 }
}