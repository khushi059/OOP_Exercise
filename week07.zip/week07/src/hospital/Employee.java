package hospital;

//Base class for all employees
class Employee {
 private int empNumber;

 public Employee(int empNumber) {
     this.empNumber = empNumber;
 }

 public int getEmpNumber() {
     return empNumber;
 }
}