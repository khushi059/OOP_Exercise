package hospital;

//Driver class
public class Hospital {
 public static void main(String[] args) {
     Doctor doctor = new Doctor(101, "Cardiology");
     Nurse nurse = new Nurse(201);
     Receptionist receptionist = new Receptionist(301);
     Cleaner cleaner = new Cleaner(401);

     // Test the methods
     doctor.treatPatient();
     nurse.assistPatient();
     receptionist.answerPhone();
     cleaner.clean();
 }
}
