package hospital;

//Nurse class
class Nurse extends Employee {
 public Nurse(int empNumber) {
     super(empNumber);
 }

 public void assistPatient() {
     System.out.println("Nurse Emp#" + getEmpNumber() + " has patients");
 }
}