package hospital;

//Receptionist class
class Receptionist extends Employee {
 public Receptionist(int empNumber) {
     super(empNumber);
 }

 public void answerPhone() {
     System.out.println("Receptionist Emp#" + getEmpNumber() + " is answering phone calls");
 }
}