package playerstatistics;

class PlayerStats {
    private String playerName;
    private int gamesPlayed;


    public PlayerStats(String playerName, int gamesPlayed) {
        this.playerName = playerName;
        this.gamesPlayed = gamesPlayed;
   
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    @Override
    public String toString() {
        return "Player: " + playerName + ", Games Played: " + gamesPlayed ;
    }
}



