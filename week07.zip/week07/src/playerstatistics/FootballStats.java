package playerstatistics;

class FootballStats extends PlayerStats {
    private int yellowCards;
    private int redCards;
    private int goalsScored;

    public FootballStats(String playerName, int gamesPlayed, int goalsScored, int yellowCards, int redCards) {
        super(playerName, gamesPlayed);
        this.goalsScored = goalsScored;
        this.yellowCards = yellowCards;
        this.redCards = redCards;
    }

    public int getGoalsScored() {
        return goalsScored;
    }

    public int getYellowCards() {
        return yellowCards;
    }

    public int getRedCards() {
        return redCards;
    }

    @Override
    public String toString() {
        return super.toString() + ", Goals Scored: " + goalsScored + ", Yellow Cards: " + yellowCards + ", Red Cards: " + redCards;
    }
}