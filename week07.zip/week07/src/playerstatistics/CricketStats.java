package playerstatistics;

class CricketStats extends PlayerStats {
    private int runsScored;
    private int wicketsTaken;

    public CricketStats(String playerName, int gamesPlayed, int runsScored, int wicketsTaken) {
        super(playerName, gamesPlayed);
        this.runsScored = runsScored;
        this.wicketsTaken = wicketsTaken;
    }

    public int getRunsScored() {
        return runsScored;
    }

    public int getWicketsTaken() {
        return wicketsTaken;
    }

    @Override
    public String toString() {
        return super.toString() + ", Runs Scored: " + runsScored + ", Wickets Taken: " + wicketsTaken;
    }
}
