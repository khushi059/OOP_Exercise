package playerstatistics;

public class SportsStats {
    public static void main(String[] args) {
        FootballStats footballPlayer = new FootballStats("Messi", 9, 11, 2, 0);
        CricketStats cricketPlayer = new CricketStats("Virat Kohli", 5, 280, 1);

        System.out.println("Football Player Stats:");
        System.out.println(footballPlayer);

        System.out.println("\nCricket Player Stats:");
        System.out.println(cricketPlayer);
    }
}
