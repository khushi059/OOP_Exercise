package Week_02;

/* Write an application that prompts for and reads integer 
representing the length of a square’s side, then prints the 
square’s perimeter and area. */

import java.util.Scanner;
public class SquareCalculation {

	public static void main(String[] args) {
	
	Scanner scan = new Scanner(System.in);
	System.out.println("Please enter the length of a square's side:");
	int side_length = scan.nextInt();
	
	//Perimeter Calculation
	
	int perimeter = 4 * side_length;
	
	//Area Calculation
	
	int area = side_length * side_length ;
	
	// Results
	
	System.out.println("The Perimeter of Square is " + perimeter + ".");
	System.out.println("The Area of Square is " + area + ".");

	scan.close();
	}

}
