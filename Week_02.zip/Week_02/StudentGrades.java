package Week_02;

public class StudentGrades {

	public static void main(String[] args) {
		//Array to store student names
		String[] names = {"Raj", "Sabin", "Sangam", "Sagar", "Snehit"};
		
		//Array to store lab points
		int[] labpoints = {68,45,70,35,30};
		
		//Array to store bonus points
		int[] bonuspoints = {11,12,7,9,11};
		
		// Print the top border
		System.out.println("///////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
		System.out.println("==         Student Points          ==");
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////");
		
				
		//Table header
		
		System.out.println("Name\t\tLab\tBonus\tTotal");
		System.out.println("----\t\t---\t-----\t-----");
		
		//Print student data
		for (int i = 0 ; i< names.length; i++) {
			int totalpoints = labpoints[i] + bonuspoints[i];
			System.out.println(names[i] + "\t\t" + labpoints[i] + "\t" + 
			bonuspoints[i] + "\t" + totalpoints);
			
		}
	}

}
