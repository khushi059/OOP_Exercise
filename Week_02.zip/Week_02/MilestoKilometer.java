package Week_02;

/*Write an application that converts miles to kilometers.
(One mile equals 1.60935 km). Read the miles from the user 
as a floating point value. */

import java.util.Scanner;
public class MilestoKilometer {

	public static void main(String[] args) {
		
	int miles;
	float kilometer;
	Scanner scn = new Scanner(System.in) ;
	
	//reading value from user
	
	System.out.println("Please enter the miles to convert to KiloMeters: ");
	miles = scn.nextInt();

	//computing the value
	
	kilometer = (float)(miles * 1.60935);
	
	System.out.println("The " + miles +  " miles is equal to " + 
	kilometer + " kilometers.");
	
	scn.close();
	}

}
