package Week_02;

/* Write an application that prompts and reads the 
numerator and denominator of a fraction as integers 
and then prints the decimal equivalent of the fraction.*/

import java.util.Scanner;
public class Fraction {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
	// promts the user for numerator and denominator
		
	System.out.println("Please enter the Numerator: ");
	int numerator = scan .nextInt();
	
	System.out.println("Please enter the denominator: ");
	int denominator = scan.nextInt();
	
	// Zero Division Error handling
	
	if (denominator == 0) {
		System.out.println("Error! Cannot divide by zero");
	} else {
		double decimalEquivalent = (double) numerator/denominator;
		System.out.println("The decimal equivalent of the given fraction is "
                  + decimalEquivalent);
	}

	scan.close();
	
	}

}
