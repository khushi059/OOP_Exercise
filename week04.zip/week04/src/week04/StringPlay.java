package week04;

//**************************************************
//StringPlay.java
//
//Play with String objects
//**************************************************

public class StringPlay {

public static void main(String[] args) {
	
	String college = new String ("Leeds Beckett University");

     // (a) declare the variable town and initialize it
     String town = "Anytown, UK"; 

     int stringLength;
     String change1, change2, change3; 


     // (b) calculate string length
     stringLength = college.length(); 


     System.out.println (college + " contains " + stringLength + " characters.");


     // (c) convert college to uppercase
     change1 = college.toUpperCase();

     // (d) replace lowercase 'e' with '*' in change1
     change2 = change1.replace('e', '*');

     // (e) concatenate college and town using concat method
     change3 = college.concat(" " + town);


     System.out.println ("Change1 result is " + change1 + ".");
     System.out.println ("Change2 result is " + change2 + ".");
     System.out.println ("The final string is " + change3 + ".");
     

    
}

}
