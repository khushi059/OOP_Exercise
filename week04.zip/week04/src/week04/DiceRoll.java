package week04;

import java.util.Scanner;
public class DiceRoll {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

      // Get number of sides for each die
        System.out.print("How many sides does die 1 have? ");
        int sidesDie1 = scanner.nextInt();
        System.out.print("How many sides does die 2 have? ");
        int sidesDie2 = scanner.nextInt();

      // Variables for tracking rolls
        int totalRollDie1 = 0;
        int totalRollDie2 = 0;
        
        for (int roll = 1; roll <= 3; roll++) {
      // Generate random numbers for each die
            int rollDie1 = (int) (Math.random() * sidesDie1) + 1;
            int rollDie2 = (int) (Math.random() * sidesDie2) + 1;

       // Print roll results
            System.out.println("Die 1 roll " + roll + " = " + rollDie1);
            System.out.println("Die 2 roll " + roll + " = " + rollDie2);

          // Update totals
            totalRollDie1 += rollDie1;
            totalRollDie2 += rollDie2;
        }

     // Calculate averages
        double averageDie1 = (double) totalRollDie1 / 3;
        double averageDie2 = (double) totalRollDie2 / 3;

     // Format averages with .2f decimals using String.format
        String formattedAverageDie1 = String.format("%.2f", averageDie1);
        String formattedAverageDie2 = String.format("%.2f", averageDie2);

     // Print averages
        System.out.println("Die 1 rolled a total of " + totalRollDie1 + " and rolled " + formattedAverageDie1 + " on average.");
        System.out.println("Die 2 rolled a total of " + totalRollDie2 + " and rolled " + formattedAverageDie2 + " on average.");
        
     // Close the scanner after user input
        scanner.close();

	}

}
