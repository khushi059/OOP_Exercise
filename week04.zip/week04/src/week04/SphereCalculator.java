package week04;

import java.util.Scanner;

public class SphereCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double radius;
        while (true) {
            System.out.print("Enter the radius of the sphere (positive value): ");
            radius = scanner.nextDouble();
            if (radius > 0) {
                break; // Break out of the loop if input is valid
            } else {
                System.out.println("Invalid input. Please enter a positive value.");
            }
        }

        double volume = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
        double surfaceArea = 4 * Math.PI * Math.pow(radius, 2);

        System.out.printf("Volume: %.4f\n", volume);
        System.out.printf("Surface Area: %.4f\n", surfaceArea);
        
        scanner.close();
    }
}
