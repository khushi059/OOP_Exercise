package Week_01;

public class PersonalDetails {

	public static void main(String[] args) {
		
		System.out.println ("My Personal Details");
		System.out.println ("-------------------");
		System.out.println ("Name: ");
		System.out.println ("Address: ");
		System.out.println ("Age: ");
		System.out.println ("Mob No: ");

	}

}
