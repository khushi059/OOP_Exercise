package Week_01;

public class Test {

	public static void main(String[] args) {
		System.out.println ("An Emergency Broadcast");

	}

}
