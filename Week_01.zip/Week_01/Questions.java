package Week_01;

public class Questions {

	public static void main(String[] args) {
	System.out.println("Answers in comment");
	/* 
	   a. What is the latest version of the Java SDK that is available?
		Ans: Java JDK 21
		
	   b. What is the difference between Java SE and Java ME?
	   	Ans: Java SE (Standard Edition) provides the core functionalities of the java language.
	   		 It provides the essential components for java application such as Java VM, Java RunTime Environment
	   		 and Java Development which helps to develop desktop application. Whereas, Java ME(Micro Edition) 
	   		 provides APIs for applications targeting embedded and mobile devices.
	   	
	   c. Which operating system is Java available for?
	    Ans: Java is available for windows, Linux, MacOS and other UNIX.
	    
	   d. What is the most popular IDE available for Java apart from Eclipse? 
	    Ans: IntelliJ IDEA.
	   
	   e. What is the main() function for in a Java program?
	    Ans: It is an entry point of the program where the code start executing.
	    */

	}

}
