package bankaccount;

import java.util.Scanner;

public class Bank {
    public static void main(String[] args) {
        // Create an array to hold up to 30 Account objects
        Account[] accounts = new Account[30];

        // Create a Scanner object to read input from the keyboard
        Scanner scanner = new Scanner(System.in);

        // Create some accounts
        System.out.println("Enter account ID:");
        int id = scanner.nextInt();
        accounts[0] = new Account(id);

        System.out.println("Enter account ID:");
        id = scanner.nextInt();
        accounts[1] = new Account(id);

        System.out.println("Enter account ID:");
        id = scanner.nextInt();
        accounts[2] = new Account(id);

        // Make some transactions
        System.out.println("Enter account ID for deposit:");
        id = scanner.nextInt();
        Account depositAccount = null;
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null && accounts[i].getId() == id) {
                depositAccount = accounts[i];
                break;
            }
        }
        if (depositAccount != null) {
            System.out.println("Enter deposit amount:");
            double amount = scanner.nextDouble();
            depositAccount.deposit(amount);
        }

        System.out.println("Enter account ID for withdrawal:");
        id = scanner.nextInt();
        Account withdrawalAccount = null;
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null && accounts[i].getId() == id) {
                withdrawalAccount = accounts[i];
                break;
            }
        }
        if (withdrawalAccount != null) {
            System.out.println("Enter withdrawal amount:");
            double amount = scanner.nextDouble();
            withdrawalAccount.withdraw(amount);
        }

        // Print account information
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                accounts[i].print();
            }
        }

        // Add interest to all accounts
        Account.addInterest();

        // Print account information again
        for (int i = 0; i < accounts.length; i++) {
            if (accounts[i] != null) {
                accounts[i].print();
            }
        }

        scanner.close();
    }
}