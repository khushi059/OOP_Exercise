package bankaccount;

public class Account {
    private static final double INTEREST_RATE = 0.03; // 3% interest rate
    private static final int MAX_CUSTOMERS = 30; // Maximum number of customers
    private static int numCustomers = 0; // Current number of customers
    private static Account[] accounts = new Account[MAX_CUSTOMERS]; // Array of accounts

    private int id;
    private double balance;

    // Constructor
    public Account(int id) {
        this.id = id;
        this.balance = 0.0;
        if (numCustomers < MAX_CUSTOMERS) {
            accounts[numCustomers++] = this;
        } else {
            System.out.println("Error: Maximum number of customers reached.");
        }
    }

    // Deposit method
    public void deposit(double amount) {
        if (amount > 0.0) {
            balance += amount;
        } else {
            System.out.println("Error: Invalid deposit amount.");
        }
    }

    // Withdrawal method
    public void withdraw(double amount) {
        if (amount > 0.0 && amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Error: Invalid withdrawal amount.");
        }
    }

    // Add interest method
    public static void addInterest() {
        for (int i = 0; i < numCustomers; i++) {
            accounts[i].balance += accounts[i].balance * INTEREST_RATE;
        }
    }

    // Getters
    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    // Print account information
    public void print() {
        System.out.println("Account ID: " + id);
        System.out.println("Balance: $" + balance);
    }
}