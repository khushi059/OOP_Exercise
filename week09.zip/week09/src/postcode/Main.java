package postcode;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Person[] people = new Person[25];
        int count = 0;

        // Read pairs of names and postal codes until "done" is entered or max limit reached
        while (count < 25) {
            System.out.print("Enter first name, last name, and postal code (separated by tabs), type 'done' to finish: ");
            String line = scanner.nextLine();
            if (line.equalsIgnoreCase("done")) {
                break;
            }
            String[] parts = line.split("\t");
            if (parts.length != 3) {
                System.out.println("Invalid input. Please enter three strings separated by tabs.");
                continue;
            }
            String firstName = parts[0];
            String lastName = parts[1];
            String postalCode = parts[2];
            people[count++] = new Person(firstName, lastName, postalCode);
        }

        // Print the list of people
        System.out.println("\nList of People:");
        System.out.println(String.format("%-15s %-15s %-10s", "First Name", "Last Name", "Postal Code"));
        for (int i = 0; i < count; i++) {
            System.out.println(people[i]);
            scanner.close();
        }
    }
}