package quiztime;

public class QuizTime {
    public static void main(String[] args) {
        Quiz quiz = new Quiz();

        // Populating the quiz with questions
        quiz.addQuestion("What is the largest planet in our solar system?", "Jupiter");
        quiz.addQuestion("What is the capital of Nepal?", "Kathmandu");
        
        // Add more questions here if needed

        // Presenting the quiz
        System.out.println("Welcome to the Quiz!");
        quiz.giveQuiz();

        // Printing final results
        System.out.println("Quiz ended. Your score: " + quiz.getScore());
    }
}
