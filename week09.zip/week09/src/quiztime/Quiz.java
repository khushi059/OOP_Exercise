package quiztime;

import java.util.Scanner;

class Quiz {
    private String[] questions;
    private String[] answers;
    private int numOfQuestions;
    private int score;

    public Quiz() {
        this.questions = new String[25];
        this.answers = new String[25];
        this.numOfQuestions = 0;
        this.score = 0;
    }

    public void addQuestion(String question, String answer) {
        if (numOfQuestions < 25) {
            questions[numOfQuestions] = question;
            answers[numOfQuestions] = answer;
            numOfQuestions++;
        } else {
            System.out.println("Maximum number of questions reached (25)");
        }
    }

    public void giveQuiz() {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < numOfQuestions; i++) {
            System.out.println(questions[i]);
            String userAnswer = scanner.nextLine().trim();;
            if (userAnswer.equalsIgnoreCase(answers[i])) {
                score++;
                
          
            }
        }
    }

    public int getScore() {
        return score;
        
      
    }
}
