package histogram;

import java.util.Scanner;

public class Histogram {
    public static void main(String[] args) {
        int[] counts = new int[10]; // Initialize an array to hold the counts for each range
        Scanner scanner = new Scanner(System.in);

        // Read in an arbitrary number of integers
        System.out.println("Enter integers between 1 and 100 (type 'done' to quit):");
        String input = scanner.next();
        while (!input.equalsIgnoreCase("done")) {
            int num = Integer.parseInt(input);
            if (num >= 1 && num <= 100) {
                int range = (num - 1) / 10; // Calculate the range (0-9, 10-19, etc.)
                counts[range]++; // Increment the count for that range
            }
            input = scanner.next();
        }

        // Print the histogram
        for (int i = 0; i < counts.length; i++) {
            int start = i * 10 + 1;
            int end = start + 9;
            System.out.printf("%d - %d  | ", start, end);
            for (int j = 0; j < counts[i]; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        scanner.close();
    }
}
